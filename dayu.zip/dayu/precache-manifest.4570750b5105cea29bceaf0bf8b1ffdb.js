self.__precacheManifest = [
  {
    "revision": "0314b34ba11f4e3cfd59",
    "url": "/dayu/assets/css/chunk-68f84f12.1686c066.css"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/dayu/robots.txt"
  },
  {
    "revision": "0314b34ba11f4e3cfd59",
    "url": "/dayu/assets/js/chunk-68f84f12.36de9333.js"
  },
  {
    "revision": "fffcfb12735aedf9a349",
    "url": "/dayu/assets/css/chunk-044fd1e1.e9bcb34d.css"
  },
  {
    "revision": "2a193ef6b3d509577362",
    "url": "/dayu/assets/css/chunk-1ab05905.97c90281.css"
  },
  {
    "revision": "2a193ef6b3d509577362",
    "url": "/dayu/assets/js/chunk-1ab05905.9c996a6f.js"
  },
  {
    "revision": "ce6481b574f5186b6b02",
    "url": "/dayu/assets/css/chunk-1b2f8e6c.e0d3fe02.css"
  },
  {
    "revision": "ce6481b574f5186b6b02",
    "url": "/dayu/assets/js/chunk-1b2f8e6c.cd8b75fa.js"
  },
  {
    "revision": "e31d8178ade218c61160",
    "url": "/dayu/assets/css/chunk-23f11c62.803ed979.css"
  },
  {
    "revision": "e31d8178ade218c61160",
    "url": "/dayu/assets/js/chunk-23f11c62.07f8631a.js"
  },
  {
    "revision": "2b81985a8f6412820bed",
    "url": "/dayu/assets/css/chunk-2536ef3c.66dfc96c.css"
  },
  {
    "revision": "2b81985a8f6412820bed",
    "url": "/dayu/assets/js/chunk-2536ef3c.90afe04c.js"
  },
  {
    "revision": "f84e83f880e7468dcd39",
    "url": "/dayu/assets/css/chunk-285f919a.1971e331.css"
  },
  {
    "revision": "f84e83f880e7468dcd39",
    "url": "/dayu/assets/js/chunk-285f919a.faf16e84.js"
  },
  {
    "revision": "3c4e97ea4d8d0311e5c3",
    "url": "/dayu/assets/css/chunk-39bc13f9.242b557c.css"
  },
  {
    "revision": "3c4e97ea4d8d0311e5c3",
    "url": "/dayu/assets/js/chunk-39bc13f9.cb581d87.js"
  },
  {
    "revision": "79b89c1e3210bf8ddb32",
    "url": "/dayu/assets/css/chunk-3bda9dfe.e9b25086.css"
  },
  {
    "revision": "79b89c1e3210bf8ddb32",
    "url": "/dayu/assets/js/chunk-3bda9dfe.b3d8804f.js"
  },
  {
    "revision": "87486b6af9bc8b83bd6e",
    "url": "/dayu/assets/css/chunk-3c074989.447387b0.css"
  },
  {
    "revision": "87486b6af9bc8b83bd6e",
    "url": "/dayu/assets/js/chunk-3c074989.baeda73f.js"
  },
  {
    "revision": "d698f22d4fd9e77aedd7",
    "url": "/dayu/assets/css/chunk-44855c10.3725b5b0.css"
  },
  {
    "revision": "d698f22d4fd9e77aedd7",
    "url": "/dayu/assets/js/chunk-44855c10.6ffb6825.js"
  },
  {
    "revision": "d70ee655f5576ee6f074",
    "url": "/dayu/assets/css/chunk-5219ff24.5c7d38f6.css"
  },
  {
    "revision": "d70ee655f5576ee6f074",
    "url": "/dayu/assets/js/chunk-5219ff24.c323b273.js"
  },
  {
    "revision": "e38bd462eb0105f9b73e",
    "url": "/dayu/assets/css/chunk-528d3454.ca630765.css"
  },
  {
    "revision": "e38bd462eb0105f9b73e",
    "url": "/dayu/assets/js/chunk-528d3454.d0f1683f.js"
  },
  {
    "revision": "2d41ee8740b0a8de56ac",
    "url": "/dayu/assets/css/chunk-5524cca4.02abc2c6.css"
  },
  {
    "revision": "2d41ee8740b0a8de56ac",
    "url": "/dayu/assets/js/chunk-5524cca4.b1a13d6a.js"
  },
  {
    "revision": "60c991caa98b4f72c08d",
    "url": "/dayu/assets/css/chunk-5883ca67.c8215f68.css"
  },
  {
    "revision": "60c991caa98b4f72c08d",
    "url": "/dayu/assets/js/chunk-5883ca67.71d4d1ed.js"
  },
  {
    "revision": "aa5f5df3338cf9fc4a2b",
    "url": "/dayu/assets/css/chunk-5c397a06.0b28a09c.css"
  },
  {
    "revision": "aa5f5df3338cf9fc4a2b",
    "url": "/dayu/assets/js/chunk-5c397a06.4e9b4891.js"
  },
  {
    "revision": "f8def55e6b854c519bce",
    "url": "/dayu/assets/css/chunk-61184b45.032a126f.css"
  },
  {
    "revision": "f8def55e6b854c519bce",
    "url": "/dayu/assets/js/chunk-61184b45.12c5ed5c.js"
  },
  {
    "revision": "44699b6aaf3106673213",
    "url": "/dayu/assets/css/chunk-659f8fa3.433ac1d9.css"
  },
  {
    "revision": "44699b6aaf3106673213",
    "url": "/dayu/assets/js/chunk-659f8fa3.a8e01489.js"
  },
  {
    "revision": "c69b3dfae79121989882",
    "url": "/dayu/assets/css/chunk-66b61abe.7677240c.css"
  },
  {
    "revision": "c69b3dfae79121989882",
    "url": "/dayu/assets/js/chunk-66b61abe.01487417.js"
  },
  {
    "revision": "7033843513c4035f7689",
    "url": "/dayu/assets/css/chunk-6769ed52.c1154648.css"
  },
  {
    "revision": "7033843513c4035f7689",
    "url": "/dayu/assets/js/chunk-6769ed52.db226f04.js"
  },
  {
    "revision": "9cfef3ff8624029992ab",
    "url": "/dayu/assets/js/app.d1719c38.js"
  },
  {
    "revision": "fffcfb12735aedf9a349",
    "url": "/dayu/assets/js/chunk-044fd1e1.154ee8dc.js"
  },
  {
    "revision": "15548b8905117cc6138f",
    "url": "/dayu/assets/css/chunk-68fd131f.385bbf14.css"
  },
  {
    "revision": "15548b8905117cc6138f",
    "url": "/dayu/assets/js/chunk-68fd131f.165b71fd.js"
  },
  {
    "revision": "a0b9572bbadd7c307318",
    "url": "/dayu/assets/css/chunk-6909cb69.499faad7.css"
  },
  {
    "revision": "a0b9572bbadd7c307318",
    "url": "/dayu/assets/js/chunk-6909cb69.4f206f63.js"
  },
  {
    "revision": "9be1ad5d23e6428a08e6",
    "url": "/dayu/assets/css/chunk-72b3df6a.d05c7733.css"
  },
  {
    "revision": "9be1ad5d23e6428a08e6",
    "url": "/dayu/assets/js/chunk-72b3df6a.82fead6a.js"
  },
  {
    "revision": "712e8eb622a4fc0a2a52",
    "url": "/dayu/assets/css/chunk-7397d848.f05ab60e.css"
  },
  {
    "revision": "712e8eb622a4fc0a2a52",
    "url": "/dayu/assets/js/chunk-7397d848.87969114.js"
  },
  {
    "revision": "575a6d6f79b8a36f2031",
    "url": "/dayu/assets/css/chunk-7935e1c2.689d6fc7.css"
  },
  {
    "revision": "575a6d6f79b8a36f2031",
    "url": "/dayu/assets/js/chunk-7935e1c2.bed6772b.js"
  },
  {
    "revision": "2556f46c20a3a6016ed4",
    "url": "/dayu/assets/css/chunk-91f32efc.a8f1ee0c.css"
  },
  {
    "revision": "2556f46c20a3a6016ed4",
    "url": "/dayu/assets/js/chunk-91f32efc.c3d938a1.js"
  },
  {
    "revision": "717f473d885be4574135",
    "url": "/dayu/assets/css/chunk-cd2d3b98.b30a7ea3.css"
  },
  {
    "revision": "717f473d885be4574135",
    "url": "/dayu/assets/js/chunk-cd2d3b98.fcdaebb8.js"
  },
  {
    "revision": "0b9815160e3562e2c56a",
    "url": "/dayu/assets/css/chunk-d158a770.6fb99be6.css"
  },
  {
    "revision": "0b9815160e3562e2c56a",
    "url": "/dayu/assets/js/chunk-d158a770.b9f566b7.js"
  },
  {
    "revision": "bf3fa4d5eab19a26ee72",
    "url": "/dayu/assets/css/chunk-e444ac12.e8b5f475.css"
  },
  {
    "revision": "bf3fa4d5eab19a26ee72",
    "url": "/dayu/assets/js/chunk-e444ac12.b309c0cc.js"
  },
  {
    "revision": "e96101a70c51683619e7",
    "url": "/dayu/assets/css/chunk-vendors.9ed2413c.css"
  },
  {
    "revision": "e96101a70c51683619e7",
    "url": "/dayu/assets/js/chunk-vendors.770ca092.js"
  },
  {
    "revision": "cef828e15a7cf06f31893d04f00d1b04",
    "url": "/dayu/assets/img/bg_mine.cef828e1.png"
  },
  {
    "revision": "8fe0bb95e82ad3abf72aeed1ce4e74a6",
    "url": "/dayu/assets/img/img_non.8fe0bb95.png"
  },
  {
    "revision": "abb6f9b2580ecb8e308729cea2a953ef",
    "url": "/dayu/assets/img/icon_send_pay.abb6f9b2.png"
  },
  {
    "revision": "42b44a94b2914b533a42fd57a7b059ca",
    "url": "/dayu/assets/img/invite_card_img1.42b44a94.png"
  },
  {
    "revision": "2b537bade1bf368c1357c3015104c501",
    "url": "/dayu/assets/img/share_index_card.2b537bad.png"
  },
  {
    "revision": "cc95bf2ddc3613a454e6171d8c832374",
    "url": "/dayu/assets/img/bg_wallet.cc95bf2d.png"
  },
  {
    "revision": "d02783de6790e8c402f700ccd2f9dc0d",
    "url": "/dayu/assets/img/invite_bg.d02783de.png"
  },
  {
    "revision": "66ec3899c1e0bc7a654635029089a3b5",
    "url": "/dayu/assets/img/img_raiders.66ec3899.png"
  },
  {
    "revision": "e519c1fe9a414a7888c5c76e5dd25a93",
    "url": "/dayu/assets/img/bg_share_dialog.e519c1fe.png"
  },
  {
    "revision": "e924ab1254cc4ab3c7a5bfdd55b07653",
    "url": "/dayu/assets/img/share_card.e924ab12.png"
  },
  {
    "revision": "ffcc40c3e63e8708c2528866ba0affa9",
    "url": "/dayu/assets/img/share_mode_img.ffcc40c3.png"
  },
  {
    "revision": "7d404621c151f59255033e0a7103185e",
    "url": "/dayu/assets/img/bg_my_mining.7d404621.png"
  },
  {
    "revision": "799a3a176d52aa57642a7c41e3805840",
    "url": "/dayu/assets/img/bg_circle.799a3a17.png"
  },
  {
    "revision": "181cc7e873c00b44ef4ad9089f2a64ac",
    "url": "/dayu/assets/img/body-placeholder.181cc7e8.png"
  },
  {
    "revision": "b2cecfcbde5335e246962140e56541c5",
    "url": "/dayu/assets/img/bg_candy_card.b2cecfcb.png"
  },
  {
    "revision": "229d60445aa2a8e57b8d18ee9d047d05",
    "url": "/dayu/assets/img/bg_new_dialog.229d6044.png"
  },
  {
    "revision": "554173c54d75c042747311ff4b81a7c1",
    "url": "/dayu/index.html"
  },
  {
    "revision": "9cfef3ff8624029992ab",
    "url": "/dayu/assets/css/app.7311b172.css"
  }
];